<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="profile" href="https://gmpg.org/xfn/11">
        <link rel="pingback" href="https://www.spheretheme.com/xmlrpc.php">

        <title>Page not found - Sphere Theme</title>
<meta name='robots' content='max-image-preview:large' />

<!-- This site is optimized with the Yoast SEO plugin v13.1 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - Sphere Theme" />
<meta property="og:site_name" content="Sphere Theme" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found - Sphere Theme" />
<meta name="twitter:site" content="@spheretheme" />
<script type='application/ld+json' class='yoast-schema-graph yoast-schema-graph--main'>{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.spheretheme.com/#website","url":"https://www.spheretheme.com/","name":"Sphere Theme","inLanguage":"en-US","publisher":{"@id":"https://www.spheretheme.com/#/schema/person/"},"potentialAction":{"@type":"SearchAction","target":"https://www.spheretheme.com/?s={search_term_string}","query-input":"required name=search_term_string"}}]}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//secure.gravatar.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//use.fontawesome.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel='dns-prefetch' href='//c0.wp.com' />
<link rel='dns-prefetch' href='//i0.wp.com' />
<link rel='dns-prefetch' href='//i1.wp.com' />
<link rel='dns-prefetch' href='//i2.wp.com' />
<link rel="alternate" type="application/rss+xml" title="Sphere Theme &raquo; Feed" href="https://www.spheretheme.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Sphere Theme &raquo; Comments Feed" href="https://www.spheretheme.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.spheretheme.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.10"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://c0.wp.com/c/5.8.10/wp-includes/css/dist/block-library/style.min.css' type='text/css' media='all' />
<style id='wp-block-library-inline-css' type='text/css'>
.has-text-align-justify{text-align:justify;}
</style>
<link rel='stylesheet' id='mediaelement-css'  href='https://c0.wp.com/c/5.8.10/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css'  href='https://c0.wp.com/c/5.8.10/wp-includes/js/mediaelement/wp-mediaelement.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://www.spheretheme.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='edd-styles-css'  href='https://www.spheretheme.com/wp-content/plugins/easy-digital-downloads/templates/edd.min.css?ver=2.9.19' type='text/css' media='all' />
<link rel='stylesheet' id='tm-google-font-css'  href='//fonts.googleapis.com/css?family=Roboto%3A400%2C300%2C700%2C700%2C600%2C600%2C600&#038;ver=5.8.10' type='text/css' media='all' />
<link rel='stylesheet' id='themeum-core-css-css'  href='https://www.spheretheme.com/wp-content/plugins/themeum-core/assets/css/themeum-core.css?ver=5.8.10' type='text/css' media='all' />
<link rel='stylesheet' id='reduxadmin-css-css'  href='https://www.spheretheme.com/wp-content/plugins/themeum-core/assets/css/themeum-core.css?ver=5.8.10' type='text/css' media='all' />
<link rel='stylesheet' id='if-menu-site-css-css'  href='https://www.spheretheme.com/wp-content/plugins/if-menu/assets/if-menu-site.css?ver=5.8.10' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='https://c0.wp.com/c/5.8.10/wp-includes/css/dashicons.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='marketify-fonts-css'  href='//fonts.googleapis.com/css?family=Source+Sans+Pro%3Aregular%2Citalic%2C700%7CMontserrat%3Aregular%2C700&#038;subset=latin%2Cvietnamese%2Clatin-ext&#038;ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='marketify-base-css'  href='https://www.spheretheme.com/wp-content/themes/sphere/style.css?ver=1.0' type='text/css' media='all' />
<style id='marketify-base-inline-css' type='text/css'>
.widget--home-taxonomy-stylized{background-color:#50ca8b;}.site-footer.site-footer--dark{background-color:#515a63;}.nav-menu--primary-toggle,.page-title{color:#ffffff;}.header-outer,.minimal,.custom-background.minimal,.wp-playlist .mejs-controls .mejs-time-rail .mejs-time-current{background-color:#515a63;}.page-header .button:hover,.page-header .button.button--color-white:hover,.home .page-header .button:hover,.page-header .edd-submit.button.edd_go_to_checkout:hover,.site-footer--light .site-title--footer a{color:#515a63;}.featured-popular-switcher span:hover{border-color:#515a63;color:#515a63;}button,input[type=reset],input[type=submit],input[type=radio]:checked,.button,#edd-purchase-button,.edd-submit,.edd-submit.button,.edd-submit.button:visited,input[type=submit].edd-submit,.current-cart .cart_item.edd_checkout a,.edd-wl-button,a.edd-wl-button,.edd-wl-button.edd-wl-action,a.edd-wl-button.edd-wl-action{color:#515a63;border-color:#515a63;background:#ffffff;}button:hover,input[type=reset]:hover,input[type=submit]:hover,.button:hover,#edd-purchase-button:hover,.edd-submit:hover,.edd-submit.button:hover,input[type=submit].edd-submit:hover,.current-cart .cart_item.edd_checkout a:hover,.edd-wl-button:hover,a.edd-wl-button:hover,.edd-wl-button.edd-wl-action:hover,a.edd-wl-button.edd-wl-action:hover{color:#ffffff;background-color:#515a63;border-color:#515a63;}.button.button--color-white:hover,.page-header .edd-submit.button.edd-add-to-cart:hover,.page-header .edd-submit.button.edd_go_to_checkout:hover,.page-header a.edd-submit.button:hover,.content-grid-download__actions .button:hover,.content-grid-download__actions .edd-submit:hover,.content-grid-download__actions a.button.edd-submit:hover,.content-grid-download__actions .edd-submit.button.edd-add-to-cart:hover,.content-grid-download__actions .edd-submit.button.edd_go_to_checkout:hover,body .marketify_widget_slider_hero .soliloquy-container .soliloquy-caption-outer .button:hover,.feature-callout-cover .button:hover{color:#515a63;background-color:#ffffff;border-color:#ffffff;}.content-grid-download__entry-image:hover .content-grid-download__overlay,.content-grid-download__entry-image.hover .content-grid-download__overlay{background:rgba(81,90,99,.80);border:1px solid rgba(81,90,99,.80);}.search-form-overlay,.download-gallery-navigation__image.slick-active:before{background-color:rgba(81,90,99, .90);}.nav-menu--primary li li a{color:#515a63;}.minimal,.custom-background.minimal{background-color:#515a63;}.minimal .section-title__inner,.minimal .edd_form fieldset > span legend,.minimal .edd_form fieldset legend span,.minimal #edd_checkout_form_wrap .edd_form fieldset > span legend,.minimal .entry-content .edd-slg-social-container > span legend,.minimal .fes-headers span{background-color:#515a63;color:#fff;}.minimal #edd_login_form input[type=submit],.minimal #edd_register_form input[type=submit],.minimal #edd-purchase-button.edd-submit.button,.minimal .fes-submit .edd-submit.button{background-color:#50ca8b;border-color:#50ca8b;color:#fff;}.minimal #edd_login_form input[type=submit]:hover,.minimal #edd_register_form input[type=submit]:hover,.minimal #edd-purchase-button.button.edd-submit:hover,.minimal .fes-submit .edd-submit.button:hover{background-color:transparent;border-color:#50ca8b;color:#50ca8b;}body{font-family:"Source Sans Pro","Helvetica Neue",Helvetica,Arial,sans-serif;font-weight:normal;line-height:1.75;}button,input[type=submit],input[type=button],input[type=reset],#edd-purchase-button,#edd_checkout_form_wrap .edd-cart-adjustment .edd-apply-discount,.button,.button--private-message-link,.cart_item.edd_checkout a,.edd-submit,.edd-submit.button,.edd-submit.button:visited,.edd-wl-button,.edd-wl-button.edd-wl-action,.edd_terms_links,.entry-content #fes-view-comment a,.facetwp-type-slider .facetwp-slider-reset,a.edd-wl-button,a.edd-wl-button.edd-wl-action,body .marketify_widget_slider_hero .soliloquy-container .soliloquy-caption-outer .button{font-family:"Montserrat","Helvetica Neue",Helvetica,Arial,sans-serif;font-weight:bold;line-height:1.5;text-transform:uppercase;}.entry-title--hentry{font-family:"Montserrat","Helvetica Neue",Helvetica,Arial,sans-serif;font-weight:bold;line-height:1.3;}.page-title{font-family:"Montserrat","Helvetica Neue",Helvetica,Arial,sans-serif;font-weight:bold;line-height:1.5;}#edd-wl-modal .modal-header h2,#edd-wl-modal .modal-header span,#edd_checkout_form_wrap fieldset#edd_cc_fields>legend span,#edd_checkout_form_wrap fieldset#edd_cc_fields>span legend,#edd_checkout_form_wrap fieldset#edd_cc_fields>span span,#edd_checkout_form_wrap fieldset>legend span,#edd_checkout_form_wrap fieldset>span legend,#edd_checkout_form_wrap fieldset>span span,#edd_checkout_wrap fieldset#edd_cc_fields>legend span,#edd_checkout_wrap fieldset#edd_cc_fields>span legend,#edd_checkout_wrap fieldset#edd_cc_fields>span span,#edd_checkout_wrap fieldset>legend span,#edd_checkout_wrap fieldset>span legend,#edd_checkout_wrap fieldset>span span,.edd-csau-products h2 span,.edd-reviews-heading span,.edd-reviews-title span,.edd-reviews-vendor-feedback-item h3 a,.edd-reviews-vendor-feedback-item h3 span,.edd-reviews-vendor-feedback-item h4 a,.edd-reviews-vendor-feedback-item h4 span,.edd_form fieldset>legend span,.edd_form fieldset>span legend,.edd_form fieldset>span span,.entry-content .edd-csau-products h2 span,.entry-content .edd-slg-social-container>span legend,.entry-content .edd-slg-social-container>span span,.entry-content .fes-headers span,.entry-content .pm-section-title span,.gform_title span,.section-title span,.section-title__inner,.widget-title--blog span{font-family:"Montserrat","Helvetica Neue",Helvetica,Arial,sans-serif;font-weight:bold;line-height:1;}
@media screen and (min-width: 992px){.nav-menu--primary li a,.nav-menu li.menu-item-has-children:after,.nav-menu li.page_item_has_children:after{color:#ffffff;}}
@media screen and (min-width: 1200px){body{font-size:16px;}button,input[type=submit],input[type=button],input[type=reset],#edd-purchase-button,#edd_checkout_form_wrap .edd-cart-adjustment .edd-apply-discount,.button,.button--private-message-link,.cart_item.edd_checkout a,.edd-submit,.edd-submit.button,.edd-submit.button:visited,.edd-wl-button,.edd-wl-button.edd-wl-action,.edd_terms_links,.entry-content #fes-view-comment a,.facetwp-type-slider .facetwp-slider-reset,a.edd-wl-button,a.edd-wl-button.edd-wl-action,body .marketify_widget_slider_hero .soliloquy-container .soliloquy-caption-outer .button{font-size:13px;}.entry-title--hentry{font-size:20px;}.page-title{font-size:36px;}#edd-wl-modal .modal-header h2,#edd-wl-modal .modal-header span,#edd_checkout_form_wrap fieldset#edd_cc_fields>legend span,#edd_checkout_form_wrap fieldset#edd_cc_fields>span legend,#edd_checkout_form_wrap fieldset#edd_cc_fields>span span,#edd_checkout_form_wrap fieldset>legend span,#edd_checkout_form_wrap fieldset>span legend,#edd_checkout_form_wrap fieldset>span span,#edd_checkout_wrap fieldset#edd_cc_fields>legend span,#edd_checkout_wrap fieldset#edd_cc_fields>span legend,#edd_checkout_wrap fieldset#edd_cc_fields>span span,#edd_checkout_wrap fieldset>legend span,#edd_checkout_wrap fieldset>span legend,#edd_checkout_wrap fieldset>span span,.edd-csau-products h2 span,.edd-reviews-heading span,.edd-reviews-title span,.edd-reviews-vendor-feedback-item h3 a,.edd-reviews-vendor-feedback-item h3 span,.edd-reviews-vendor-feedback-item h4 a,.edd-reviews-vendor-feedback-item h4 span,.edd_form fieldset>legend span,.edd_form fieldset>span legend,.edd_form fieldset>span span,.entry-content .edd-csau-products h2 span,.entry-content .edd-slg-social-container>span legend,.entry-content .edd-slg-social-container>span span,.entry-content .fes-headers span,.entry-content .pm-section-title span,.gform_title span,.section-title span,.section-title__inner,.widget-title--blog span{font-size:15px;}}
</style>
<link rel='stylesheet' id='marketify-child-css'  href='https://www.spheretheme.com/wp-content/themes/sphere-child/style.css?ver=5.8.10' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='//use.fontawesome.com/releases/v5.6.3/css/all.css?ver=5.8.10' type='text/css' media='all' />
<link rel='stylesheet' id='jetpack_css-css'  href='https://c0.wp.com/p/jetpack/10.4.1/css/jetpack.css' type='text/css' media='all' />
<script>if (document.location.protocol != "https:") {document.location = document.URL.replace(/^http:/i, "https:");}</script><script type='text/javascript' src='https://c0.wp.com/c/5.8.10/wp-includes/js/jquery/jquery.min.js' id='jquery-core-js'></script>
<script type='text/javascript' src='https://c0.wp.com/c/5.8.10/wp-includes/js/jquery/jquery-migrate.min.js' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/plugins/themeum-core/assets/js/custom.js?ver=5.8.10' id='custom-js'></script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/plugins/themeum-core/assets/js/jquery.isotope.min.js?ver=5.8.10' id='isotop-js'></script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/plugins/themeum-core/assets/js/jquery.magnific-popup.min.js?ver=5.8.10' id='magnific-js'></script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/themes/sphere-child/custom.js?ver=5.8.10' id='custom-script-js'></script>
<script type='text/javascript' id='marketify-js-extra'>
/* <![CDATA[ */
var Marketify = {"widgets":{"testimonials":{"individualSliderSpeed":3000}}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/themes/sphere/js/marketify.min.js?ver=1.0' id='marketify-js'></script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/themes/sphere/js/download/download.js?ver=1.0' id='marketify-download-js'></script>
<link rel="https://api.w.org/" href="https://www.spheretheme.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.spheretheme.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.spheretheme.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.10" />
<meta name="generator" content="Easy Digital Downloads v2.9.19" />
<meta name="generator" content="EDD FES v2.6.2" />
<style type='text/css'>img#wpstats{display:none}</style>
			<style type="text/css">
		.site-branding .site-title,
	.site-branding .site-description,
	.site-title--minimal {
	display: none;
	}
		.site-title a,
	.site-description {
		color: #blank;
	}
	</style>
			<style type="text/css">
				/* If html does not have either class, do not show lazy loaded images. */
				html:not( .jetpack-lazy-images-js-enabled ):not( .js ) .jetpack-lazy-image {
					display: none;
				}
			</style>
			<script>
				document.documentElement.classList.add(
					'jetpack-lazy-images-js-enabled'
				);
			</script>
		<link rel="icon" href="https://i1.wp.com/www.spheretheme.com/wp-content/uploads/2019/02/icon.png?fit=32%2C21&#038;ssl=1" sizes="32x32" />
<link rel="icon" href="https://i1.wp.com/www.spheretheme.com/wp-content/uploads/2019/02/icon.png?fit=90%2C60&#038;ssl=1" sizes="192x192" />
<link rel="apple-touch-icon" href="https://i1.wp.com/www.spheretheme.com/wp-content/uploads/2019/02/icon.png?fit=90%2C60&#038;ssl=1" />
<meta name="msapplication-TileImage" content="https://i1.wp.com/www.spheretheme.com/wp-content/uploads/2019/02/icon.png?fit=90%2C60&#038;ssl=1" />
    </head>
    <body data-rsssl=1 class="error404 marketify-plugin-edd marketify-plugin-edd-fes marketify-plugin-jetpack marketify-plugin-multiple-post-thumbnails feature-location-">

        <div id="page" class="hfeed site">

            <!-- Top bar -->
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 d-sm-flex align-items-center">
                            <div class="header-top-contact">
                                <span><i class="fas fa-fw fa-envelope"></i> info@spheretheme.com</span>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="header-top-right">
                                <ul>
                                    <li><a target="new" href="https://www.facebook.com/spheretheme"><i class="fab fa-fw fa-facebook-f"></i></a></li>
                                    <li><a target="new" href="https://twitter.com/spheretheme"><i class="fab fa-fw fa-twitter"></i></a></li>
                                    <li><a target="new" href="#"><i class="fab fa-fw fa-google-plus-g"></i></a></li>
                                    <li><a target="new" href="#"><i class="fab fa-fw fa-linkedin-in"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Top bar -->



            <div class="header-outer no-image has-video"style="" >

                <header id="masthead" class="site-header" role="banner">
                    <div class="container">

                        <div class="site-header-inner">

                            <div class="site-branding">
                                                                                                    <a href="https://www.spheretheme.com/" title="Sphere Theme" rel="home" class="custom-header"><img src="https://www.spheretheme.com/wp-content/uploads/2019/01/logo-2.png" alt=""></a>
                                
                                <h1 class="site-title"><a href="https://www.spheretheme.com/" rel="home">Sphere Theme</a></h1>
                                <h2 class="site-description screen-reader-text"></h2>
                            </div>

                            <button class="js-toggle-nav-menu--primary nav-menu--primary-toggle"><span class="screen-reader-text">Menu</span></button>

                            <div class="nav-menu nav-menu--primary"><ul id="menu-primary" class="menu"><li id="menu-item-151" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-151"><a href="https://www.spheretheme.com/">Home</a></li>
<li id="menu-item-157" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-157"><a href="https://www.spheretheme.com/products/">Products</a></li>
<li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67"><a href="https://www.spheretheme.com/login/">Sign In</a></li>
<li id="menu-item-65" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-65"><a href="https://www.spheretheme.com/register/">Join Now</a></li>
<li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="https://www.spheretheme.com/contact-us/">Contact us</a></li>

            <li class="current-cart menu-item menu-item-has-children">
                <a href="https://www.spheretheme.com/checkout/"><span class="edd-cart-quantity">0</span></a>
                <a href="https://www.spheretheme.com/checkout/"><span class="edd-checkout-link">Checkout</span></a>
                <ul class="sub-menu nav-menu"><li class="widget"><p class="edd-cart-number-of-items" style="display:none;">Number of items in cart: <span class="edd-cart-quantity">0</span></p>
<ul class="edd-cart">

	<li class="cart_item empty"><span class="edd_empty_cart">Your cart is empty.</span></li>
<li class="cart_item edd-cart-meta edd_total" style="display:none;">Total: <span class="cart-total">&#36;0.00</span></li>
<li class="cart_item edd_checkout" style="display:none;"><a href="https://www.spheretheme.com/checkout/">Checkout</a></li>

</ul>
</li></ul>
            </li><li class="nav-menu-search"><a href="#" class="js-toggle-search"><span class="screen-reader-text">Search</span></a>
<form role="search" method="get" class="search-form" action="https://www.spheretheme.com/">
	<label class="screen-reader-text" for="s">Search for:</label>
	<input type="search" class="search-field" placeholder="Search" value="" name="s" title="Search for:">
	<input type="hidden" name="post_type" value="download" />

	<button type="submit" class="search-submit"><span class="screen-reader-text">Search</span></button>
	<a href="#" class="js-toggle-search js-toggle-search--close"><span class="screen-reader-text">Close</span></a>
</form>
</li></ul></div>
                        </div>

                    </div>
                </header><!-- #masthead -->

                <div class="search-form-overlay">
                    
<form role="search" method="get" class="search-form" action="https://www.spheretheme.com/">
	<label class="screen-reader-text" for="s">Search for:</label>
	<input type="search" class="search-field" placeholder="Search" value="" name="s" title="Search for:">
	<input type="hidden" name="post_type" value="download" />

	<button type="submit" class="search-submit"><span class="screen-reader-text">Search</span></button>
	<a href="#" class="js-toggle-search js-toggle-search--close"><span class="screen-reader-text">Close</span></a>
</form>
                </div>

	<div class="page-header page-header--singular container">
	<h2 class="page-title">Oops! That page can&rsquo;t be found.</h2>
</div></div>
	<div class="container">
		<div id="content" class="site-content row">

			<div id="primary" class="content-area col-sm-8">
				<main id="main" class="site-main" role="main">

				<section class="error-404 not-found">
					<div class="page-content">
						<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>

						
<form role="search" method="get" class="search-form" action="https://www.spheretheme.com/">
<button type="submit" class="search-submit"><span class="screen-reader-text">Submit</span></button>
	<label>
		<span class="screen-reader-text">Search for:</span>
		<input type="search" class="search-field" placeholder="Search" value="" name="s" title="Search for:">
	</label>

	<input type="hidden" name="post_type" value="post" />
</form>

						<div class="row not-found-links">
							<div class="col-md-6">
															</div>

							<div class="col-md-6">
								<div class="widget widget_categories">
									<h3 class="widget-title">Most Used Categories</h3>
									<ul>
									<li class="cat-item-none">No categories</li>									</ul>
								</div><!-- .widget -->
							</div>
						</div>

					</div><!-- .page-content -->
				</section><!-- .error-404 -->

				</main><!-- #main -->
			</div><!-- #primary -->

			<div class="widget-area col-xs-12 col-md-4" role="complementary">
	
	<aside id="search-2" class="widget widget--blog widget_search">
<form role="search" method="get" class="search-form" action="https://www.spheretheme.com/">
<button type="submit" class="search-submit"><span class="screen-reader-text">Submit</span></button>
	<label>
		<span class="screen-reader-text">Search for:</span>
		<input type="search" class="search-field" placeholder="Search" value="" name="s" title="Search for:">
	</label>

	<input type="hidden" name="post_type" value="post" />
</form>
</aside><aside id="edd_categories_tags_widget-1" class="widget widget--blog widget_edd_categories_tags_widget"><ul class="edd-taxonomy-widget">
	<li class="cat-item cat-item-19"><a href="https://www.spheretheme.com/downloads/category/html/">HTML</a>
</li>
	<li class="cat-item cat-item-12"><a href="https://www.spheretheme.com/downloads/category/wordpress/">WordPress</a>
</li>
</ul>
</aside></div><!-- #secondary -->
		</div>
	</div>


<footer id="colophon" class="site-footer site-footer--light" role="contentinfo">
        <div class="footer-top">
        <div class="container">
            <div class="row">
                                    <div class="col-sm-6 col-md-3">
                        <aside id="nav_menu-3" class="widget_nav_menu"><h3 class="widget-title widget-title--site-footer">For Customers</h3><div class="menu-for-customers-container"><ul id="menu-for-customers" class="menu"><li id="menu-item-305" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-305"><a href="https://www.spheretheme.com/item-support/">Item Support</a></li>
<li id="menu-item-304" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-304"><a href="https://www.spheretheme.com/customers-faqs/">Customer’s FAQs</a></li>
<li id="menu-item-303" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-303"><a href="https://www.spheretheme.com/refund-policy/">Refund Policy</a></li>
<li id="menu-item-243" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-243"><a href="https://www.spheretheme.com/privacy-policy/">Privacy Policy</a></li>
</ul></div></aside>                    </div>
                 
                                    <div class="col-sm-6 col-md-3">
                        <aside id="nav_menu-4" class="widget_nav_menu"><h3 class="widget-title widget-title--site-footer">For Authors</h3><div class="menu-for-authors-container"><ul id="menu-for-authors" class="menu"><li id="menu-item-644" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-644"><a href="https://www.spheretheme.com/become-an-author/">Become an Author</a></li>
<li id="menu-item-645" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-645"><a href="https://www.spheretheme.com/author-faq/">Author FAQ</a></li>
<li id="menu-item-646" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-646"><a href="https://www.spheretheme.com/submission-guideline/">Submission Guideline</a></li>
</ul></div></aside>                    </div>
                 
                                    <div class="col-sm-6 col-md-3">
                        <aside id="nav_menu-2" class="widget_nav_menu"><h3 class="widget-title widget-title--site-footer">Useful Links</h3><div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="menu"><li id="menu-item-178" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-178"><a target="_blank" rel="noopener" href="http://support.spheretheme.com/">Support</a></li>
<li id="menu-item-179" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-179"><a target="_blank" rel="noopener" href="http://support.spheretheme.com/forums/">Forums</a></li>
<li id="menu-item-180" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-180"><a target="_blank" rel="noopener" href="http://support.spheretheme.com/knowledgebase/">knowledgebase</a></li>
</ul></div></aside>                    </div>
                 
                                    <div class="col-sm-6 col-md-3">
                        <aside id="marketify-widget-footer-social-icons-3" class="marketify-widget-footer-social-icons"><h3 class="widget-title widget-title--site-footer">Social</h3><div class="footer-social"><a href="http://facebook.com/spheretheme/"><span class="screen-reader-text">Facebook</span></a>
<a href="http://twitter.com/spheretheme"><span class="screen-reader-text">Twitter</span></a>
<a href="http://instagram.com"><span class="screen-reader-text">Instagram</span></a>
<a href="http://plus.google.com"><span class="screen-reader-text">Google Plus</span></a>
<a href="http://pinterest.com"><span class="screen-reader-text">Pinterest</span></a>
</div></aside>                    </div>
                 
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row clearfix">
                                    <div class="col-sm-12 col-md-12">
                        <div class="footer-copyright">
                                                                                           
                        </div> 
                        <!-- col-md-6 -->
                    </div> 
                 
                <!-- end footer-copyright -->

            </div><!--/.row clearfix-->    
        </div>
    </div>
    
</footer><!-- #colophon -->





</div><!-- #page -->

<script type='text/javascript' src='https://c0.wp.com/p/jetpack/10.4.1/_inc/build/photon/photon.min.js' id='jetpack-photon-js'></script>
<script type='text/javascript' src='https://c0.wp.com/c/5.8.10/wp-includes/js/dist/vendor/regenerator-runtime.min.js' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://c0.wp.com/c/5.8.10/wp-includes/js/dist/vendor/wp-polyfill.min.js' id='wp-polyfill-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/www.spheretheme.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.5.3' id='contact-form-7-js'></script>
<script type='text/javascript' id='edd-ajax-js-extra'>
/* <![CDATA[ */
var edd_scripts = {"ajaxurl":"https:\/\/www.spheretheme.com\/wp-admin\/admin-ajax.php","position_in_cart":"-1","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","is_checkout":"0","default_gateway":"paypal","redirect_to_checkout":"1","checkout_page":"https:\/\/www.spheretheme.com\/checkout\/","permalinks":"1","quantities_enabled":"","taxes_enabled":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/plugins/easy-digital-downloads/assets/js/edd-ajax.min.js?ver=2.9.19' id='edd-ajax-js'></script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/plugins/jetpack/vendor/automattic/jetpack-lazy-images/dist/intersection-observer.js?minify=false&#038;ver=2d4bf43f398489795f1893179047a63c' id='jetpack-lazy-images-polyfill-intersectionobserver-js'></script>
<script type='text/javascript' id='jetpack-lazy-images-js-extra'>
/* <![CDATA[ */
var jetpackLazyImagesL10n = {"loading_warning":"Images are still loading. Please cancel your print and try again."};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.spheretheme.com/wp-content/plugins/jetpack/vendor/automattic/jetpack-lazy-images/dist/lazy-images.js?minify=false&#038;ver=1c8bb5930b723e669774487342a8fa98' id='jetpack-lazy-images-js'></script>
<script type='text/javascript' src='https://c0.wp.com/c/5.8.10/wp-includes/js/wp-embed.min.js' id='wp-embed-js'></script>
<script src='https://stats.wp.com/e-202440.js' defer></script>
<script>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:10.4.1',blog:'157899206',post:'0',tz:'0',srv:'www.spheretheme.com'} ]);
	_stq.push([ 'clickTrackerInit', '157899206', '0' ]);
</script>

</body>
</html>
